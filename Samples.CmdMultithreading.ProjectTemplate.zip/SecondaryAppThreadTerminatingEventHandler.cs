﻿
namespace $safeprojectname$
{
    public delegate void SecondaryAppThreadTerminatingEventHandler(int id);
}
